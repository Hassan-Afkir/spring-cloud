package org.sid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceProxyApplicationTests {

	@Test
	void contextLoads() {
	}

}
